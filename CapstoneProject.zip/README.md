The main python library used in this notebook is lightGBM by Microsoft.  Sci-kit learn is also used.

See documentation:
	https://lightgbm.readthedocs.io/en/latest/
	https://scikit-learn.org/stable/index.html


All data used in this project can be accessed by using 
the following commands in the online Bertelsmann/Arvato 
Jupyter notebook:

azdias = pd.read_csv('../../data/Term2/capstone/arvato_data/Udacity_AZDIAS_052018.csv', sep=';')
customers = pd.read_csv('../../data/Term2/capstone/arvato_data/Udacity_CUSTOMERS_052018.csv', sep=';')
train = pd.read_csv('../../data/Term2/capstone/arvato_data/Udacity_MAILOUT_052018_TRAIN.csv', sep=';')
test = pd.read_csv('../../data/Term2/capstone/arvato_data/Udacity_MAILOUT_052018_TEST.csv', sep=';')